"""Signal Audit — does this dataset contain the signals the brief assumes?

Run BEFORE building anything on top of a signal. Every claim the final system
makes must survive this file.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import pandas as pd
from scipy import stats

from src.ingest import load_all
from src.opinion_units import OpinionUnitEngine
from src.temporal import benjamini_hochberg

r, p, _ = load_all()
u = OpinionUnitEngine().fit(r).transform(r)
m = u.merge(r[["review_id", "hotel_id", "review_date", "traveler_type", "hotel_category", "city"]],
            on="review_id")
m["t"] = (m.review_date - m.review_date.min()).dt.days / 365.25
m["ispos"] = (m.polarity > 0).astype(int)

print("\n" + "=" * 78)
print("TEST 1 — Do hotels genuinely DIFFER on aspects? (is there anything to rank on?)")
print("=" * 78)
piv = m.pivot_table(index="hotel_id", columns="aspect", values="ispos",
                    aggfunc=["mean", "size"])
res = []
for asp in sorted(m.aspect.unique()):
    sub = m[m.aspect == asp]
    tab = pd.crosstab(sub.hotel_id, sub.ispos)
    tab = tab[tab.sum(axis=1) >= 15]
    if tab.shape[0] < 20 or tab.shape[1] < 2:
        continue
    chi2, pv, dof, _ = stats.chi2_contingency(tab)
    v = np.sqrt(chi2 / (tab.values.sum() * (min(tab.shape) - 1)))  # Cramer's V
    res.append((asp, pv, v, tab.shape[0]))
res_df = pd.DataFrame(res, columns=["aspect", "p", "cramers_v", "n_hotels"])
res_df["discovery"] = benjamini_hochberg(res_df.p.to_numpy())
print(res_df.sort_values("cramers_v", ascending=False).to_string(index=False))
print(f"\n=> {int(res_df.discovery.sum())}/{len(res_df)} aspects differentiate hotels "
      f"after BH-FDR. Mean Cramer's V = {res_df.cramers_v.mean():.3f}")

print("\n" + "=" * 78)
print("TEST 2 — Temporal drift, tested at REVIEW level (max power, not 24 monthly means)")
print("=" * 78)
rows = []
for (h, a), g in m.groupby(["hotel_id", "aspect"]):
    if len(g) < 40 or g.ispos.nunique() < 2:
        continue
    # logistic slope of P(positive) on time, via Wald test
    x = g.t.to_numpy()
    y = g.ispos.to_numpy()
    rho, pv = stats.pointbiserialr(y, x)
    rows.append((h, a, len(g), rho, pv))
d = pd.DataFrame(rows, columns=["hotel_id", "aspect", "n", "rho", "p"])
d["discovery"] = benjamini_hochberg(d.p.to_numpy(), 0.05)
print(f"tests: {len(d)} | raw p<.05: {int((d.p < .05).sum())} "
      f"(expected by chance: {0.05*len(d):.0f}) | survive BH-FDR: {int(d.discovery.sum())}")
if d.discovery.any():
    print(d[d.discovery].reindex(d[d.discovery].rho.abs().sort_values(ascending=False).index)
          .head(12).to_string(index=False))

print("\n--- hotel-level OVERALL rating trend, review-level Spearman ---")
rows = []
for h, g in r.groupby("hotel_id"):
    t = (g.review_date - r.review_date.min()).dt.days / 365.25
    rho, pv = stats.spearmanr(g.rating, t)
    rows.append((h, len(g), rho, pv))
t_df = pd.DataFrame(rows, columns=["hotel_id", "n", "rho", "p"])
t_df["discovery"] = benjamini_hochberg(t_df.p.to_numpy(), 0.05)
print(f"tests: {len(t_df)} | raw p<.05: {int((t_df.p < .05).sum())} "
      f"(expected: {0.05*len(t_df):.0f}) | survive BH-FDR: {int(t_df.discovery.sum())}")
print(t_df[t_df.discovery].sort_values("rho").to_string(index=False))

print("\n" + "=" * 78)
print("TEST 3 — Is traveler_type informative about review content at all?")
print("=" * 78)
lab = m.dropna(subset=["traveler_type"])
tab = pd.crosstab(lab.traveler_type, lab.aspect)
chi2, pv, dof, _ = stats.chi2_contingency(tab)
v = np.sqrt(chi2 / (tab.values.sum() * (min(tab.shape) - 1)))
print(f"traveler_type x aspect: chi2={chi2:.1f}, p={pv:.4f}, Cramer's V={v:.4f}")
tab2 = pd.crosstab(lab.traveler_type, lab.ispos)
chi2b, pvb, _, _ = stats.chi2_contingency(tab2)
print(f"traveler_type x polarity: chi2={chi2b:.1f}, p={pvb:.4f}")
print("\n=> If V ~ 0 and p >> .05, traveler_type was assigned INDEPENDENTLY of the "
      "review text.\n   Any 'cohort disagreement' insight built on it would be pure noise.")

print("\n" + "=" * 78)
print("TEST 4 — Do hotel_category / city carry aspect signal? (sanity: some things MUST)")
print("=" * 78)
for col in ["hotel_category", "city"]:
    tab = pd.crosstab(m[col], m.aspect)
    chi2, pv, _, _ = stats.chi2_contingency(tab)
    v = np.sqrt(chi2 / (tab.values.sum() * (min(tab.shape) - 1)))
    print(f"{col:16s} x aspect  : Cramer's V={v:.4f}  p={pv:.3g}")
    sub = m[m.aspect == "luxury"]
    tab2 = pd.crosstab(sub[col], sub.ispos)
    chi2, pv, _, _ = stats.chi2_contingency(tab2)
    print(f"{col:16s} x luxury-positivity: p={pv:.3g}")
